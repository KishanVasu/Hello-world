This folder contains files related to design and testing of Asynchronous FIFO. 
Some design files include :
Dff1.vhd : Single stage synchronizer
Dff2.vhd : Two stage synchronizer
BtoG.vhd : Binary to Gray Converter
GtoB.vhd : Gray to Binary Converter
Xorgate.vhd : Xor operation 
Write_control.vhd : Write control module for controlling of write pointer and write enable pins 
Read_control.vhd : Read control module for controlling of read pointer and read enable pins 
Mem.vhd : Memory design for the FIFO
Controller.vhd : Top level controler which acts as DUT for testing. It instantiates all other modules and takes inputs for the FIFO and gives the required output

Verification files are written in System Verilog. They include:
Interface.sv : Defines various interfaces for the communication between modules
Randomization.sv : Random class for the generation of the test inputs 
Test.sv : Contains cover groups and performs cover group analysis and passes the test cases to the DUT
Checker.sv : Checker module double cross checks the full, empty, almost full and almost empty flags using the read and write pointers
Top.sv : Top level module for the verification which instatiates the DUT and other testing modules

Command for execution :
irun -gui -access +rwc -f filelist -top top 

Command for verification :
irun -access +rwc -f filelist -top top -coverage all -covoverwrite
imc