
#use Excel::Writer::XLSX;
use Spreadsheet::WriteExcel;
use Spreadsheet::ParseExcel;
# Create a new Excel workbook

#use Spreadsheet::WriteExcel;

#my $workbook =  Spreadsheet::WriteExcel->new('2a.xls');
#
$x=0;
while($x<= $#ARGV)
{
	$file=$ARGV[$x];
#	print "File:$file1.file";
	my $parser = Spreadsheet::ParseExcel->new();
	my $workbook = $parser->parse($file);

if ( !defined $workbook ) {
        die $parser->error(), ".\n";
    }
else
{
	print "Opening file :$file\n";
}

#Add a worksheet
for my $worksheet( $workbook->worksheets())
{
#$worksheet = $workbook->add_worksheet();
#add Data
#$worksheet->write('A1','Kishan');
#$worksheet->write('A2','Guruchethan');
#$worksheet->write('A3','Girish');
#$worksheet->write('A4','Now');
#my @row=row($worksheet,$A);
my ( $row_min, $row_max ) = $worksheet->row_range();
my ( $col_min, $col_max ) = $worksheet->col_range();

for my $row ( $row_min .. $row_max )
{
	@arr1="";
	print "Arr1=$arr1\n";	
        for my $col ( $col_min .. $col_max )
	{
		my $cell = $worksheet->get_cell($row,$col);
   		next unless $cell != undef;	
		my $value = $cell->value();
		push(@arr1,$value);
	}
	print"Array1afterL1=@arr1\n";
	push (@arr,@arr1);
	print "Array2: @arr\n";
	print "Array2[2]=$arr[2]\n";
	print "Array2[4]=$arr[4]\n";
}
}
$x++;
}
print "Stating to sort";
$j=0;

print scalar @arr."\n";
$arrno=(scalar @arr);
print "ARRno : $arrno\n";

@arr = grep { $_ ne '' } @arr;
print "Printing grep Array: @arr \n";

$arrno=(scalar @arr);
print "ARRno : $arrno\n";

while($j<$arrno)
{
	if ($arr[$j] =~ /^[a-zA-Z\s\.]+$/ && $arr[$j+1] =~ /^[0-9]+$/)
        {
 
		@arr2[$j]=join("\t",$arr[$j],$arr[$j+1]);
		$j=$j+2;
	}
	else
	{$j++;}

}

#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort {(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr2;
#open the new file where the sorted array is to be outputed
	open($sorted,'>',"sorted2.txt") or die "Can't open output.txt";
	#print the sorted array in the new text file	
	 my $workbook = Spreadsheet::WriteExcel->new('Excel.xls');
	    $worksheet   = $workbook->add_worksheet();  
	   # $worksheet->write('A1', 'Hi Excel!');       
	   $i=1;
		foreach (@out)
	        {	
			print $_; 
                        print "\n";
                      	print $sorted $_."\n";
			@a=split(/\t/,$_);
			$worksheet->write("A$i",$a[0]);
			$worksheet->write("B$i",$a[1]);
			$i++;
		 }
 $worksheet   = $workbook->add_worksheet();     
#-------------------------------------------------------------------
 print "Sorted :) \n";
#----------------------------------------------------------------------------
#
#END of File
