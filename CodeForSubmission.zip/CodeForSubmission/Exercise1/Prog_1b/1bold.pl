use strict;
#declaration of variables
my ($file1,$file2,$f1,$f2,$output,$line,@arr,@out,$sorted);

print "Welcome. This is a program to sort the names present in two files and store the output in a new file.\n";
#input File 1 from the User
in1:print "Please enter file_name 1 :";
	$file1=<STDIN>;#take input from keyboard
	chomp $file1; #to remove newlinw characters
	if(open($f1,'<',$file1)) # check if file1 exists and can be opened
	{
		print "Opening file :$file1\n";
		goto in2;
	}
	else # else re-input file name
	{
		print "Couldn't open file $file1\n";
		goto in1;
	}
#---------------------------------------------------------------------------
#input file 2 from the User
in2:print "Please enter file_name 2:";
	$file2=<STDIN>;#take input from kayboard
	chomp $file2;# to remove newline characters
	if(open($f2,'<',$file2))#check if file2 exists and can be opened
	{
		print "Opening file : $file2\n";
		goto process;
	}
	else
	{
		print "Couldn't open file $file2\n";#else re enter the file 2
		goto in2;
	}
#---------------------------------------------------------------------------
process:
	open($output,'>',"output.txt") or die "Can't open output.txt";#open the file in write mode. Previous output in the file will be deleted
	print "Procesing\n";
	
	w1:while($line=<$f1>)
	{
		if($line=~/^ *$/)#check for empty lines in the text files
		{
			next w1;
		}
		chomp $line;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
	open($output,'>>',"output.txt") or die "Can't open output.txt";#open the file in append mode
      #-------------------------------------------------------------------
	w2:while($line=<$f2>)
	{
		 if($line=~/^ *$/)#check for empty lines in the text files
                {
                        next w2;
                }
		chomp $line;;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
	#-----------------------------------------------------------------
#	foreach(@arr)
#	{
#		print $_;
#  		print "\n"; 
#       }

#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort{(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr ;
#open the new file where the sorted array is to be outputed
	open($sorted,'>',"sorted.txt") or die "Can't open output.txt";
#print the sorted array in the new text file	
	foreach (@out)
	{	
		
		printf "%+40s",$_; 
                print "\n";
		printf $sorted "%+40s",$_."\n";
        }
#------------------------------------------------------------------------------
	print "Sorted :) \n";
#-----------------------------------------------------------------------------

#END of File
