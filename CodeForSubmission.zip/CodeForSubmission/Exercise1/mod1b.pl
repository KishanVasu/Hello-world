print "Welcome. This is a program to sort the names present in two files and store the output in a new file.\n";
inputs();#subroutine to check inputs
process();#subroutine to arrange the files after appending
outputs();#subroutine to display the outputs on terminal and the file

sub inputs
{
#input File 1 from the User
in1:
	$file1=@ARGV[0];
	chomp $file1; #to remove newlinw characters
 # check if file1 exists and can be opened
	open($f1,'<',$file1) or die "Could not open file $file1\n Please re-enter\n";
	print "Opening file :$file1\n";
	#-------------------------------------------------------------------
#input file 2 from the User
in2:
	$file2=@ARGV[1];
	chomp $file2;# to remove newline characters
   #check if file2 exists and can be opened
	open($f2,'<',$file2) or die "Could not open file $file2\n Please re-enter\n";
	print "Opening file : $file2\n";

}
#---------------------------------------------------------------------------
sub process
{
	open($output,'>',"output.txt") or die "Can't open output.txt";#open the file in write mode. Previous output in the file will be deleted
	print "Procesing\n";
	
	w1:while($line=<$f1>)
	{
		if($line=~/^ *$/)#check for empty lines in the text files
		{
			next w1;
		}
		chomp $line;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
	open($output,'>>',"output.txt") or die "Can't open output.txt";#open the file in append mode
      #-------------------------------------------------------------------
	w2:while($line=<$f2>)
	{
		 if($line=~/^ *$/)#check for empty lines in the text files
                {
                        next w2;
                }
		chomp $line;;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
}
#-------------------------------------------------------------------------------
#for checking intermediate results
#	foreach(@arr)
#	{
#		print $_;
#  		print "\n"; 
#       }
#-------------------------------------------------------------------------------

sub outputs
{
#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort{(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr ;
#open the new file where the sorted array is to be outputed
	open($sorted,'>',"sorted2.txt") or die "Can't open output.txt";
#print the sorted array in the new text file	
	foreach (@out)

        {	printf " %-40s",$_; 
                print "\n";
		printf $sorted "%-40s", $_."\n";
        }
#------------------------------------------------------------------------------
	print "\nFiles Sorted :) \n";
#------------------------------------------------------------------------------
}

#END of File
#------------------------------------
#-------------------------------
#-------------------------
#-----------------
