Files:
read_control_tb : Testbench for verifying read controller
write_control_tb : Testbench for verifying write controller
ab_afifo : Testbench for complete implementation