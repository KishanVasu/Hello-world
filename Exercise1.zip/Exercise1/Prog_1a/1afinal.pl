print "Welcome. This is a program to sort the names present in two files and store the output in a new file.\n";

in1:print "Please enter file_name 1 :";
	$file1=<STDIN>;
	chomp $file1;
	if(open($f1,'<',$file1))
	{
		print "Opening file :$file1\n";
		goto in2;
	}
	else
	{
		print "Couldn't open file $file1\n";
		goto in1;
	}
in2:print "Please enter file_name 2:";
	$file2=<STDIN>;
	chomp $file2;
	if(open($f2,'<',$file2))
	{
		print "Opening file : $file2\n";
		goto process;
	}
	else
	{
		print "Couldn't open file $file2\n";
		goto in2;
	}
process:
	open($output,'>',"output.txt") or die "Can't open output.txt";
	print "Procesing\n";
	#File :: COPY
	#copy($f1,$output) or die "Can't Copy file 1";
	#copy($f2,$output) or die "Can't Copy file 2";
	w1:while($line=<$f1>)
	{
		if($line=~/^ *$/)
		{
			next w1;
		}
		chomp $line;
		push (@arr,$line);
		print $output $line."\n";
	}
	close($output);
	open($output,'>>',"output.txt") or die "Can't open output.txt";
	w2:while($line=<$f2>)
	{
		 if($line=~/^ *$/)
                {
                        next w2;
                }
		chomp $line;
		push (@arr,$line);
		print $output $line."\n";
	}
	close($output);

#	foreach(@arr)
#	{
#		print $_;
#  		print "\n"; 
#       }

	my @out=sort @arr ;
	open($sorted,'>',"sorted.txt") or die "Can't open output.txt";
	
	foreach (@out)
        {	print $_; 
                print "\n";
		print $sorted $_."\n";
        }

	print "Sorted :) \n";
