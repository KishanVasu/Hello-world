
#use Excel::Writer::XLSX;
use Spreadsheet::WriteExcel;
use Spreadsheet::ParseExcel;
use strict;


#declaration of variables
my ($file,$f1,$f2,$output,$line,@arr,@out,$sorted,$workbook,$worksheet,$row,$col,@arr1,@arr2,$arrno);

print "Welcome. This is a program to sort the names present in two files and store the output in a new file.\n";
inputs();#subroutine to check inputs
outputs();#subroutine to display the outputs on terminal and the file

#=====================================================================================================================================================================================
sub inputs
{
	#input Files from the User
	my $size=@ARGV;
	if ($size<1)# to check if minimun of 1 file is inputed for sorting
	{	
		die " File names missing.\n Please re-enter\nThe format for executing the file is :\nmake perl 1a.pl <file1> <file2>\nWhere <file1> and <file2> are the 2 input files with .txt extension. Also make sure that the input files are in the same working directory..!!";
	}

	#variable to keep a count of number of files
	my $x=0; #---- loop control variable

	#repeat till all fileas are inputed
	while($x<= $#ARGV)
	{
		$file=$ARGV[$x];
		chomp $file;  #to remove the trailing newline character
	#	print "File:$file1.file";
		if (-e $file)  #check if the input file exists
		{
			#to check the read permisions of the file
	 		die "The file $file does not have read permissions. Please change the permissions by typing: \nchmod +r $file in the command prompt before executing" unless -r $file ;
			# print "Inside f1\n";		
		}
		else
		{
			print "File:$file does not exist\n";
		}
		
		#creating a perser object to read data from files
		my $parser = Spreadsheet::ParseExcel->new();
		my $workbook = $parser->parse($file);

	if ( !defined $workbook ) {
        	die $parser->error(), ".\nFailed to open $file\nThe format for executing the file is :\nperl 2a.pl <file1> <file2>\nWhere <file1> and <file2> are the 2 input files with .xls extension. Also make sure that the input files are in the same working directory..!! Please Re-enter $file \n";
    	}
	else
	{
		print "Opening file :$file\n";
	}

#Add a worksheet
for my $worksheet( $workbook->worksheets())
{
	#find maximum row and column length that is present in the inputed files
	my ( $row_min, $row_max ) = $worksheet->row_range();
	my ( $col_min, $col_max ) = $worksheet->col_range();

	#repeat till all the data is read from the file
	for my $row ( $row_min .. $row_max )
	{
		@arr1="";
		#print "Arr1=$arr1\n";	
	        for my $col ( $col_min .. $col_max )
		{
			my $cell = $worksheet->get_cell($row,$col);  #get the location of the cell
	   		next unless $cell != undef;	 #skip if the cell is undefined
			my $value = $cell->value();  #extract the value from the cell
			push(@arr1,$value);   #push the value obtained into an array
		}
		#print"Array1afterL1=@arr1\n";
		push (@arr,@arr1); #push into one more array. Used just for convenience...
		#print "Array2: @arr\n";
		#print "Array2[2]=$arr[2]\n";
		#print "Array2[4]=$arr[4]\n";
	}
}
$x++; # incrementing the file count 
}
}#end of the loop
#--------------------------------------------------------------------------------------
#=======================================================================================================================================================================================

sub outputs
{
	print "Starting to sort\n";
	my $j=0;

	#print scalar @arr."\n";
	#variable to find the no of elements on the array
	$arrno=(scalar @arr);
	#print "ARRno : $arrno\n";

	#grep is a command to remove all witespaces in the array i.e. if any element of the array is a whitespace, it removes it and appends the remaining art of the array at that point...!
	@arr = grep { $_ ne '' } @arr;
	print "Printing grep Array: @arr \n";

	#variable to find the no of elements on the array after grep
	$arrno=(scalar @arr);
	print "ARRno : $arrno\n";

	while($j<$arrno)
	{
		if ($arr[$j] =~ /^[a-zA-Z\s\.]+$/ && $arr[$j+1] =~ /^[0-9]+$/)       #check if the input as a name or a no. This is done to eliminate the sort if only either name or marks is entered and its pair is missing. 
	       {
 			@arr2[$j]=join("\t",$arr[$j],$arr[$j+1]);    #join the name and the marks of an entry using a tab space and store it into a new array
			$j=$j+2;
		}
		else
		{$j++;}
	}
	
		#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort {(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr2;
		#open the new file where the sorted array is to be outputed

		#check for sorted.txt file
	my $outfile="sorted.txt";
	if (-e $outfile)  #check if the input file exists
	{
		#to check the read permisions of the file
	 	die "The file $outfile does not have write permissions. Please change the permissions by typing: \nchmod +w $outfile in the command prompt before executing" unless -w $outfile ;
		# print "Inside f1\n";
		print "\nValid TEXT file \n" if -r _;
		#open the new file where the sorted array is to be outputed
		open($sorted,'>',$outfile) or die "Can't open output.txt";
	}

	else
	{
		#open the new file where the sorted array is to be outputed
		open($sorted,'>',"sorted.txt") or die "Can't open sorted.txt";
	}

	#check for Excel.xls file
	my $outfile="Excel.xls";
	if (-e $outfile)  #check if the input file exists
	{
		#to check the read permisions of the file
	 	die "The file $outfile does not have write permissions. Please change the permissions by typing: \nchmod +w $outfile in the command prompt before executing" unless -w $outfile ;
		# print "Inside f1\n";
		print "\nValid Excel file \n" if -w _;
		
	}

	#print the sorted array in the new text file	
	 my $workbook = Spreadsheet::WriteExcel->new('Excel.xls');
	    $worksheet   = $workbook->add_worksheet();  
	   # $worksheet->write('A1', 'Hi Excel!');       
	   my $i=1;
	   my @a;
		foreach (@out)
	        {	
			print $_; 
                        print "\n";
                      	print $sorted $_."\n";
			@a=split(/\t/,$_);    #store the output in a array which is split by a tabspace
			$worksheet->write("A$i",$a[0]);  #print the name in column 1
			$worksheet->write("B$i",$a[1]);  #print the marks in column 2
			$i++;
		 }
  }
#-------------------------------------------------------------------------------------------------------------
	print "Sorted :) \n";
	print "\nThe output is stored in File: Excel.xls and in sorted.txt in the same working directory....!!\n";
#-------------------------------------------------------------------------------------------------------------
#===============================================================================================================================================================================================================
#END of File
#------------------------------------
#-------------------------------
#-------------------------
#-----------------
