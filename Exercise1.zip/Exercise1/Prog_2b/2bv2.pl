
#use Excel::Writer::XLSX;
use Spreadsheet::WriteExcel;
use Spreadsheet::ParseExcel;
# Create a new Excel workbook

#use Spreadsheet::WriteExcel;

#my $workbook =  Spreadsheet::WriteExcel->new('2a.xls');
#
$x=0;
while($x<=$#ARGV)
{
#	#$size = @ARGV;
#	print "Size: $size\n";
	print "Back\n";
	$file=$ARGV[$x];
#	print "File:$file1.file";
	my $parser = Spreadsheet::ParseExcel->new();
	my $workbook = $parser->parse($file);

	if ( !defined $workbook ) {
        	die $parser->error(), ".\n";
    	}
	else
	{
		print "Opening file :$file\n";
	}	

#Add a worksheet
	for my $worksheet( $workbook->worksheets())
	{
#$worksheet = $workbook->add_worksheet();
#add Data
#$worksheet->write('A1','Kishan');
#$worksheet->write('A2','Guruchethan');
#$worksheet->write('A3','Girish');
#$worksheet->write('A4','Now');
#my @row=row($worksheet,$A);
		my ( $row_min, $row_max ) = $worksheet->row_range();
		my ( $col_min, $col_max ) = $worksheet->col_range();
		print "colm=$col_min colmx=$col_max rowm=$row_min rowmx=$row_max\n";
		for my $row ( $row_min .. $row_max )
		{	
			@arr1="";
			print "Arr1=$arr1\n";	
			for my $col ( $col_min .. $col_max )
			{
	
				my $cell = $worksheet->get_cell($row,$col);
				next unless $cell != undef;	
				my $value = $cell->value();
				#print "Value=$value\n";
				push (@arr1,$value);
			}
			print"Array1afterL1=@arr1\n";
			push (@arr,@arr1);
			print "Array2: @arr\n";
			print "Array2[2]=$arr[2]\n";
			print "Array2[4]=$arr[4]\n";
		}
	print "reach 1\n";
	}
	print "reach 2\n\n\n\n";
$x++;
}
print "Stating to sort";
$j=1;
$i=0;
print scalar @arr;
while(j<=(scalar @arr))
{
	$arr2[$i]=join("\t",$arr[$i],$arr[$i+1]);
	$j=$j+3;
	$i++;
}
#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort {(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr2;
#open the new file where the sorted array is to be outputed
	open($sorted,'>',"sorted.txt") or die "Can't open output.txt";
	#print the sorted array in the new text file	
	 my $workbook = Spreadsheet::WriteExcel->new('Excel.xls');
	    $worksheet   = $workbook->add_worksheet();  
	   # $worksheet->write('A1', 'Hi Excel!');       
	   $i=1;
		foreach (@out)
	        {	
			print $_; 
                        print "\n";
                      	print $sorted $_."\n";
			$worksheet->write("A$i",$_."\n");
			$i++;
		 }
# $worksheet  = $workbook->add_worksheet();     
#-------------------------------------------------------------------
 print "Sorted :) \n";
#----------------------------------------------------------------------------
#
#END of File
