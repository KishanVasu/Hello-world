use strict;

#declaration of variables
my ($file1,$file2,$f1,$f2,$output,$line,@arr,@out,$sorted);

print "\nWelcome. This is a program to sort the names present in two files and store the output in a new file.\n";
inputs();#subroutine to check inputs
process();#subroutine to arrange the files after appending
outputs();#subroutine to display the outputs on terminal and the file

#===============================================================================================================================================================================
sub inputs
{
	my $size=@ARGV;
	if ($size<2)
	{	
		die " File names missing.\n Please re-enter\nThe format for executing the file is :\nmake perl 1a.pl <file1> <file2>\nWhere <file1> and <file2> are the 2 input files with .txt extension. Also make sure that the input files are in the same working directory..!!";
	}


#input File 1 from the User
in1:
	$file1=@ARGV[0];
	chomp $file1; #to remove newlinw characters
	if (-e $file1)  #check if the input file exists
	{
		#to check the read permisions of the file
	 	die "The file $file2 does not have read permissions. Please change the permissions by typing: \nchmod +r $file1 in the command prompt before executing" unless -r $file1 ;
		# print "Inside f1\n";		
		if (-T $file1)  #check if the input file is a text file, else display error
		{
		
			print "\nReadable 1 \n" if -r _;
		}
		else
		{
			die "$file1 is not a text file. Please enter only valid text files\n";
		}
	}

	else
	{
	print "File:$file1 does not exit\n";
	}

 # check if file1 exists and can be opened
	open($f1,'<',$file1) or die "Could not open file $file1\n Please re-enter\nThe format for executing the file is :\nmake perl 1a.pl <file1> <file2>\nWhere <file1> and <file2> are the 2 input files with .txt extension. Also make sure that the input files are in the same working directory..!!";
	print "Opening file :$file1\n";

#----------------------------------------------------------------------------------------------------------------------------------------------------
#input file 2 from the User
in2:
	$file2=@ARGV[1];
	chomp $file2;# to remove newline characters
   	if (-e $file2)  #check if the input file exists
	{
		#to check the read permisions of the file
	 	die "The file $file2 does not have read permissions. Please change the permissions by typing: \nchmod +r $file1 in the command prompt before executing" unless -r $file1 ;
		# print "Inside f1\n";
		if (-T $file2)  #check if the input file is a text file, else display error
		{
			print "\nReadable 2 \n" if -r _;
		}
		else
		{
			die "$file1 is not a text file. Please enter only valid text files\n";
		}
	}

	else
	{
		print "File:$file2 does not exit\n";
	}

	#check if file2 exists and can be opened
	open($f2,'<',$file2) or die "Could not open file $file2\n Please re-enter\nThe format for executing the file is :\nmake makefile <file1> <file2>\nWhere <file1> and <file2> are the 2 input files with .txt extension. Also make sure that the input files are in the same working directory..!!";

	print "Opening file : $file2\n";

}

#=========================================================================================================================================================================================
sub process
{

process:
	open($output,'>',"output.txt") or die "Can't open output.txt";#open the file in write mode. Previous output in the file will be deleted
	print "Procesing\n";
	
	w1:while($line=<$f1>)
	{
		if($line=~/^ *$/)#check for empty lines in the text files
		{
			next w1;
		}
		chomp $line;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
	open($output,'>>',"output.txt") or die "Can't open output.txt";#open the file in append mode
#-------------------------------------------------------------------
	w2:while($line=<$f2>)
	{
		 if($line=~/^ *$/)#check for empty lines in the text files
                {
                        next w2;
                }
		chomp $line;;#removal of newline character from the String in the line
		push (@arr,$line);#append it to the array
		print $output $line."\n";
	}
	close($output);#close the file
}

#--------------------------------------------------------------------
#	foreach(@arr)
#	{
#		print $_;
#  		print "\n"; 
#       }
#--------------------------------------------------------------------

#===========================================================================================================================================================================================
sub outputs
{
	#Sort the array based on the marks obtained. Here we are assuming that marks are entered in the second column which is seperated by a tab space after the first field
	my @out=sort{(split('\t', $b))[1] <=> (split('\t', $a))[1] } @arr ;
	#open the new file where the sorted array is to be outputed
	open($sorted,'>',"sorted.txt") or die "Can't open output.txt";
	my $outfile="sorted.txt";
	if (-e $outfile)  #check if the input file exists
	{
		#to check the read permisions of the file
	 	die "The file $outfile does not have write permissions. Please change the permissions by typing: \nchmod +w $outfile in the command prompt before executing" unless -w $outfile ;
		# print "Inside f1\n";
		
			print "\nValid TEXT file \n" if -r _;
			#open the new file where the sorted array is to be outputed
			open($sorted,'>',$outfile) or die "Can't open output.txt";		
	}

	else
	{
		#open the new file where the sorted array is to be outputed
		open($sorted,'>',"sorted.txt") or die "Can't open sorted.txt";
	}

#print the sorted array in the new text file	
	printf $sorted "%40s","Names \t \tMarks\n";
	printf "Names \t\t Marks\n";
	foreach (@out)
	{	
		printf "%-40s",$_; 
              print "\n";
		printf $sorted "%40s",$_."\n";
        }
#-------------------------------------------------------------------------------------------
	print "Sorted :) \n";
	print "\nThe output is stored in File: output.txt in the same working directory....!!\n";
#-------------------------------------------------------------------------------------------

}
#================================================================================================================================================================================================
#END of File
#-------------------------------------------------------------------
#-----------------------------------------------------
#---------------------------------------
#----------------------------
